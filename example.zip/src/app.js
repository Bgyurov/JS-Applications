import { logout } from './api/user.js'
import { render, page } from './lib.js'
import { getUserData } from './util.js'
import { showHome } from './views/home.js'
import { showLogin } from './views/login.js'
import { updateNav } from './views/nav.js'
import { showRegister } from './views/register.js'
import { showSearch } from './views/search.js'

const main = document.getElementById('main-content')
    // document.getElementById("logoutBtn").addEventListener('click',onLogout)

page(decorateContext)
page('/', showHome)
page('/catalog', () => console.log('catalog'))
page('/catalog/:id', () => console.log('details'))
page('/search', showSearch)
page('/edit/:id', () => console.log('edit'))
page('/login', showLogin)
page('/register', showRegister)
page('/create', () => console.log('create'))

updateNav()
page.start()

function decorateContext(ctx, next) {
    ctx.render = renderMain
    ctx.updateNav = updateNav

    const user = getUserData()
    if (user) {
        ctx.user = user
    }

    next()

}

function renderMain(content) {
    render(content, main)
}